-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Apr 08, 2017 at 01:50 AM
-- Server version: 5.5.42
-- PHP Version: 7.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) unsigned NOT NULL,
  `brand_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=283 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `brands_stores`
--

CREATE TABLE `brands_stores` (
  `id` bigint(20) unsigned NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands_stores`
--

INSERT INTO `brands_stores` (`id`, `brand_id`, `store_id`) VALUES
(1, 29, 25),
(2, 30, 26),
(3, 30, 27),
(4, 31, 32),
(5, 34, 34),
(6, 32, 34),
(7, 37, 35),
(8, 38, 36),
(9, 38, 37),
(10, 39, 42),
(11, 44, 44),
(12, 40, 44),
(13, 45, 45),
(14, 46, 46),
(15, 46, 47),
(16, 47, 52),
(17, 54, 54),
(18, 48, 54),
(19, 53, 55),
(20, 54, 56),
(21, 54, 57),
(22, 55, 62),
(23, 64, 64),
(24, 56, 64),
(25, 61, 65),
(26, 62, 66),
(27, 62, 67),
(28, 63, 72),
(29, 70, 74),
(30, 71, 75),
(31, 71, 76),
(32, 72, 81),
(33, 73, 82),
(34, 74, 82),
(35, 79, 83),
(36, 80, 84),
(37, 80, 85),
(38, 81, 90),
(39, 82, 91),
(40, 83, 91),
(41, 88, 92),
(42, 89, 93),
(43, 89, 94),
(44, 90, 99),
(45, 91, 100),
(46, 92, 100),
(47, 97, 101),
(48, 98, 102),
(49, 98, 103),
(51, 100, 109),
(52, 101, 110),
(53, 102, 110),
(54, 103, 111),
(55, 108, 112),
(56, 109, 113),
(57, 109, 114),
(59, 111, 120),
(60, 112, 121),
(61, 113, 121),
(63, 120, 123),
(64, 121, 124),
(65, 121, 125),
(67, 123, 132),
(68, 124, 133),
(69, 125, 133),
(71, 132, 135),
(72, 133, 136),
(73, 133, 137),
(75, 135, 144),
(76, 136, 145),
(77, 137, 145),
(79, 144, 147),
(80, 145, 148),
(81, 145, 149),
(83, 149, 156),
(84, 150, 157),
(85, 151, 157),
(87, 159, 160),
(88, 160, 161),
(89, 160, 162),
(91, 164, 169),
(92, 165, 170),
(93, 166, 170),
(95, 174, 173),
(96, 175, 174),
(97, 175, 175),
(99, 179, 182),
(100, 180, 183),
(101, 181, 183),
(103, 189, 186),
(104, 190, 187),
(105, 190, 188),
(107, 194, 195),
(108, 195, 196),
(109, 196, 196),
(111, 204, 199),
(112, 205, 200),
(113, 205, 201),
(115, 209, 208),
(116, 210, 209),
(117, 211, 209),
(119, 218, 213),
(120, 219, 214),
(121, 219, 215),
(123, 223, 222),
(124, 224, 223),
(125, 225, 223),
(127, 232, 227),
(128, 233, 228),
(129, 233, 229),
(131, 237, 236),
(132, 238, 237),
(133, 239, 237),
(135, 246, 241),
(136, 247, 242),
(137, 247, 243),
(139, 251, 250),
(140, 252, 251),
(141, 253, 251),
(143, 260, 255),
(144, 261, 256),
(145, 261, 257),
(147, 265, 264),
(148, 266, 265),
(149, 267, 265),
(151, 274, 269),
(152, 275, 270),
(153, 275, 271),
(155, 279, 278),
(156, 280, 279),
(157, 281, 279);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) unsigned NOT NULL,
  `store_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=283 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brands_stores`
--
ALTER TABLE `brands_stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=283;
--
-- AUTO_INCREMENT for table `brands_stores`
--
ALTER TABLE `brands_stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=283;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
